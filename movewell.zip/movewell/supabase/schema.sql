-- =====================================================================
-- MOVEWELL WELLNESS CENTER — Supabase schema (Phase 1)
-- Client records, visits (services + vitals + payment), bookings,
-- services catalog, staff roles, business settings.
--
-- Run once in: Supabase Dashboard → SQL Editor → New query → Run.
-- Safe to re-run: tables use IF NOT EXISTS, functions/policies are replaced.
-- =====================================================================

create extension if not exists pgcrypto;

-- ---------------------------------------------------------------------
-- STAFF  (therapists without a login can still be listed here)
-- ---------------------------------------------------------------------
create table if not exists public.staff (
  id           uuid primary key default gen_random_uuid(),
  user_id      uuid unique references auth.users(id) on delete set null,
  full_name    text not null,
  email        text unique,
  role         text not null default 'pending'
               check (role in ('admin','frontdesk','therapist','doctor','pending')),
  prc_license  text,
  phone        text,
  active       boolean not null default true,
  created_at   timestamptz not null default now()
);

-- Role helpers (security definer so RLS policies can call them safely)
create or replace function public.my_staff_id() returns uuid
language sql stable security definer set search_path = public as $$
  select id from public.staff where user_id = auth.uid() and active limit 1
$$;

create or replace function public.my_role() returns text
language sql stable security definer set search_path = public as $$
  select role from public.staff where user_id = auth.uid() and active limit 1
$$;

create or replace function public.is_staff() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce(public.my_role() in ('admin','frontdesk','therapist','doctor'), false)
$$;

create or replace function public.can_manage() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce(public.my_role() in ('admin','frontdesk'), false)
$$;

create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce(public.my_role() = 'admin', false)
$$;

-- New login → link to an existing staff row with the same email,
-- otherwise create a 'pending' staff row. The very first account becomes admin.
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
declare
  v_first boolean;
  v_id    uuid;
begin
  select not exists (select 1 from public.staff where user_id is not null) into v_first;

  update public.staff
     set user_id = new.id
   where lower(email) = lower(new.email) and user_id is null
  returning id into v_id;

  if v_id is null then
    insert into public.staff (user_id, full_name, email, role)
    values (new.id,
            coalesce(new.raw_user_meta_data->>'full_name', split_part(new.email, '@', 1)),
            lower(new.email),
            case when v_first then 'admin' else 'pending' end);
  elsif v_first then
    update public.staff set role = 'admin' where id = v_id;
  end if;
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- Generic updated_at toucher
create or replace function public.touch_updated_at() returns trigger
language plpgsql as $$
begin new.updated_at := now(); return new; end $$;

-- ---------------------------------------------------------------------
-- SERVICES CATALOG  (feeds the public website and the visit form)
-- ---------------------------------------------------------------------
create table if not exists public.services (
  id            uuid primary key default gen_random_uuid(),
  category      text not null,
  name          text not null,
  duration_min  int,
  price         numeric(12,2),          -- null = "inquire"
  description   text,
  is_iv         boolean not null default false,  -- shows IV fields on the visit form
  active        boolean not null default true,
  show_on_site  boolean not null default true,
  coming_soon   boolean not null default false,
  sort_order    int not null default 0,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
drop trigger if exists trg_services_updated on public.services;
create trigger trg_services_updated before update on public.services
  for each row execute function public.touch_updated_at();

-- ---------------------------------------------------------------------
-- CLIENTS
-- ---------------------------------------------------------------------
create sequence if not exists public.client_no_seq;

create table if not exists public.clients (
  id               uuid primary key default gen_random_uuid(),
  client_no        text not null unique
                   default ('MW-' || lpad(nextval('public.client_no_seq')::text, 5, '0')),
  first_name       text not null,
  last_name        text not null,
  sex              text check (sex in ('Male','Female')),
  birthdate        date,
  phone            text,
  email            text,
  address          text,
  emergency_name   text,
  emergency_phone  text,
  conditions       text[] not null default '{}',   -- health screening flags
  allergies        text,
  medications      text,
  health_notes     text,
  consent_given    boolean not null default false,
  consent_at       timestamptz,
  notes            text,
  created_by       uuid references public.staff(id) default public.my_staff_id(),
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now()
);
create index if not exists idx_clients_name on public.clients (lower(last_name), lower(first_name));
create index if not exists idx_clients_phone on public.clients (phone);
drop trigger if exists trg_clients_updated on public.clients;
create trigger trg_clients_updated before update on public.clients
  for each row execute function public.touch_updated_at();

-- ---------------------------------------------------------------------
-- BOOKINGS  (website form inserts here; staff confirm / convert to visit)
-- ---------------------------------------------------------------------
create table if not exists public.bookings (
  id              uuid primary key default gen_random_uuid(),
  full_name       text not null check (char_length(full_name) between 2 and 120),
  phone           text not null check (char_length(phone) between 7 and 30),
  email           text check (email is null or char_length(email) <= 160),
  service_id      uuid references public.services(id) on delete set null,
  service_name    text check (service_name is null or char_length(service_name) <= 160),
  preferred_date  date not null,
  preferred_time  time,
  message         text check (message is null or char_length(message) <= 1000),
  source          text not null default 'website'
                  check (source in ('website','messenger','phone','walk-in','instagram','other')),
  status          text not null default 'pending'
                  check (status in ('pending','confirmed','done','cancelled','no_show')),
  client_id       uuid references public.clients(id) on delete set null,
  visit_id        uuid,
  staff_notes     text,
  handled_by      uuid references public.staff(id),
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);
create index if not exists idx_bookings_status_date on public.bookings (status, preferred_date);
drop trigger if exists trg_bookings_updated on public.bookings;
create trigger trg_bookings_updated before update on public.bookings
  for each row execute function public.touch_updated_at();

-- ---------------------------------------------------------------------
-- VISITS  (one row per client visit: vitals, IV details, payment)
-- ---------------------------------------------------------------------
create sequence if not exists public.visit_no_seq;

create table if not exists public.visits (
  id               uuid primary key default gen_random_uuid(),
  visit_no         text not null unique
                   default ('V-' || lpad(nextval('public.visit_no_seq')::text, 6, '0')),
  client_id        uuid not null references public.clients(id) on delete restrict,
  visit_date       date not null default ((now() at time zone 'Asia/Manila')::date),
  time_in          time,
  attended_by      uuid references public.staff(id),
  purpose          text,

  -- vitals before
  bp_pre_sys   smallint, bp_pre_dia smallint, hr_pre smallint, rr_pre smallint,
  temp_pre     numeric(4,1), spo2_pre smallint, weight_kg numeric(5,1),
  pain_pre     smallint check (pain_pre between 0 and 10),
  -- vitals after
  bp_post_sys  smallint, bp_post_dia smallint, hr_post smallint, spo2_post smallint,
  pain_post    smallint check (pain_post between 0 and 10),

  -- IV therapy (only filled when an IV service is availed)
  iv_doctor_id  uuid references public.staff(id),
  iv_solution   text,
  iv_lot_no     text,
  iv_site       text,
  iv_reaction   text,

  notes            text,

  -- money
  subtotal         numeric(12,2) not null default 0,
  discount_type    text not null default 'none'
                   check (discount_type in ('none','senior','pwd','promo_pct','promo_amt')),
  discount_value   numeric(12,2) not null default 0,
  discount_amount  numeric(12,2) not null default 0,
  total            numeric(12,2) not null default 0,
  payment_method   text check (payment_method in ('cash','gcash','maya','card','bank','other')),
  reference_no     text,
  amount_paid      numeric(12,2) not null default 0,
  payment_status   text not null default 'unpaid'
                   check (payment_status in ('paid','partial','unpaid')),

  booking_id       uuid references public.bookings(id) on delete set null,
  voided           boolean not null default false,
  void_reason      text,
  voided_at        timestamptz,
  created_by       uuid references public.staff(id) default public.my_staff_id(),
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now()
);
create index if not exists idx_visits_date on public.visits (visit_date);
create index if not exists idx_visits_client on public.visits (client_id, visit_date desc);
drop trigger if exists trg_visits_updated on public.visits;
create trigger trg_visits_updated before update on public.visits
  for each row execute function public.touch_updated_at();

do $$ begin
  alter table public.bookings
    add constraint bookings_visit_fk foreign key (visit_id) references public.visits(id) on delete set null;
exception when duplicate_object then null; end $$;

-- Line items: what was done, by whom (staff_id is kept per item for future commission/payroll)
create table if not exists public.visit_items (
  id            uuid primary key default gen_random_uuid(),
  visit_id      uuid not null references public.visits(id) on delete cascade,
  service_id    uuid references public.services(id) on delete set null,
  service_name  text not null,
  category      text,
  duration_min  int,
  is_iv         boolean not null default false,
  unit_price    numeric(12,2) not null default 0,
  qty           int not null default 1 check (qty > 0),
  line_total    numeric(12,2) generated always as (unit_price * qty) stored,
  staff_id      uuid references public.staff(id),
  created_at    timestamptz not null default now()
);
create index if not exists idx_visit_items_visit on public.visit_items (visit_id);
create index if not exists idx_visit_items_staff on public.visit_items (staff_id);

-- ---------------------------------------------------------------------
-- SETTINGS  (business info shown on the website)
-- ---------------------------------------------------------------------
create table if not exists public.settings (
  key         text primary key,
  value       jsonb not null,
  updated_at  timestamptz not null default now()
);

-- ---------------------------------------------------------------------
-- RPC: save a visit + its items atomically; totals computed server-side
-- ---------------------------------------------------------------------
create or replace function public.save_visit(p jsonb) returns uuid
language plpgsql security invoker set search_path = public as $$
declare
  r        public.visits;
  v_id     uuid := nullif(p->>'id', '')::uuid;
  v_items  jsonb := coalesce(p->'items', '[]'::jsonb);
  v_sub    numeric(12,2);
  v_disc   numeric(12,2);
  v_total  numeric(12,2);
  v_paid   numeric(12,2);
  v_type   text;
  v_val    numeric(12,2);
  v_status text;
begin
  if not public.is_staff() then
    raise exception 'Not authorized';
  end if;
  if jsonb_array_length(v_items) = 0 then
    raise exception 'Add at least one service';
  end if;

  r := jsonb_populate_record(null::public.visits, p);
  if r.client_id is null then raise exception 'Client is required'; end if;

  select coalesce(sum(coalesce((i->>'unit_price')::numeric, 0)
                    * greatest(coalesce((i->>'qty')::int, 1), 1)), 0)
    into v_sub
    from jsonb_array_elements(v_items) i;

  v_type := coalesce(r.discount_type, 'none');
  v_val  := greatest(coalesce(r.discount_value, 0), 0);
  v_disc := case v_type
              when 'senior'    then round(v_sub * 0.20, 2)
              when 'pwd'       then round(v_sub * 0.20, 2)
              when 'promo_pct' then round(v_sub * least(v_val, 100) / 100, 2)
              when 'promo_amt' then least(v_val, v_sub)
              else 0 end;
  v_total  := v_sub - v_disc;
  v_paid   := least(greatest(coalesce((p->>'amount_paid')::numeric, 0), 0), v_total);  -- change is not revenue
  v_status := case when v_paid >= v_total then 'paid'
                   when v_paid > 0        then 'partial'
                   else 'unpaid' end;

  if v_id is null then
    insert into public.visits (
      client_id, visit_date, time_in, attended_by, purpose,
      bp_pre_sys, bp_pre_dia, hr_pre, rr_pre, temp_pre, spo2_pre, weight_kg, pain_pre,
      bp_post_sys, bp_post_dia, hr_post, spo2_post, pain_post,
      iv_doctor_id, iv_solution, iv_lot_no, iv_site, iv_reaction, notes,
      subtotal, discount_type, discount_value, discount_amount, total,
      payment_method, reference_no, amount_paid, payment_status, booking_id)
    values (
      r.client_id, coalesce(r.visit_date, (now() at time zone 'Asia/Manila')::date), r.time_in, r.attended_by, r.purpose,
      r.bp_pre_sys, r.bp_pre_dia, r.hr_pre, r.rr_pre, r.temp_pre, r.spo2_pre, r.weight_kg, r.pain_pre,
      r.bp_post_sys, r.bp_post_dia, r.hr_post, r.spo2_post, r.pain_post,
      r.iv_doctor_id, r.iv_solution, r.iv_lot_no, r.iv_site, r.iv_reaction, r.notes,
      v_sub, v_type, v_val, v_disc, v_total,
      r.payment_method, r.reference_no, v_paid, v_status, r.booking_id)
    returning id into v_id;
  else
    update public.visits set
      client_id = r.client_id,
      visit_date = coalesce(r.visit_date, visit_date), time_in = r.time_in,
      attended_by = r.attended_by, purpose = r.purpose,
      bp_pre_sys = r.bp_pre_sys, bp_pre_dia = r.bp_pre_dia, hr_pre = r.hr_pre, rr_pre = r.rr_pre,
      temp_pre = r.temp_pre, spo2_pre = r.spo2_pre, weight_kg = r.weight_kg, pain_pre = r.pain_pre,
      bp_post_sys = r.bp_post_sys, bp_post_dia = r.bp_post_dia, hr_post = r.hr_post,
      spo2_post = r.spo2_post, pain_post = r.pain_post,
      iv_doctor_id = r.iv_doctor_id, iv_solution = r.iv_solution, iv_lot_no = r.iv_lot_no,
      iv_site = r.iv_site, iv_reaction = r.iv_reaction, notes = r.notes,
      subtotal = v_sub, discount_type = v_type, discount_value = v_val,
      discount_amount = v_disc, total = v_total,
      payment_method = r.payment_method, reference_no = r.reference_no,
      amount_paid = v_paid, payment_status = v_status
    where id = v_id and not voided;
    if not found then raise exception 'Visit not found or already voided'; end if;
    delete from public.visit_items where visit_id = v_id;
  end if;

  insert into public.visit_items
    (visit_id, service_id, service_name, category, duration_min, is_iv, unit_price, qty, staff_id)
  select v_id,
         nullif(i->>'service_id', '')::uuid,
         coalesce(nullif(i->>'service_name', ''), 'Service'),
         nullif(i->>'category', ''),
         nullif(i->>'duration_min', '')::int,
         coalesce((i->>'is_iv')::boolean, false),
         coalesce((i->>'unit_price')::numeric, 0),
         greatest(coalesce((i->>'qty')::int, 1), 1),
         nullif(i->>'staff_id', '')::uuid
    from jsonb_array_elements(v_items) i;

  if r.booking_id is not null then
    update public.bookings
       set status = 'done', visit_id = v_id, client_id = r.client_id
     where id = r.booking_id;
  end if;

  return v_id;
end $$;

create or replace function public.void_visit(p_id uuid, p_reason text) returns void
language plpgsql security invoker set search_path = public as $$
begin
  if not public.can_manage() then raise exception 'Only admin or front desk can void a visit'; end if;
  if coalesce(trim(p_reason), '') = '' then raise exception 'A reason is required'; end if;
  update public.visits
     set voided = true, void_reason = p_reason, voided_at = now()
   where id = p_id and not voided;
  if not found then raise exception 'Visit not found or already voided'; end if;
end $$;

revoke execute on function public.save_visit(jsonb) from anon;
revoke execute on function public.void_visit(uuid, text) from anon;

-- ---------------------------------------------------------------------
-- ROW LEVEL SECURITY
-- Public (anon): read active services + settings, submit a booking.
-- Staff: everything else. Patient data is never readable by the public.
-- ---------------------------------------------------------------------
alter table public.staff       enable row level security;
alter table public.services    enable row level security;
alter table public.clients     enable row level security;
alter table public.bookings    enable row level security;
alter table public.visits      enable row level security;
alter table public.visit_items enable row level security;
alter table public.settings    enable row level security;

-- staff
drop policy if exists staff_select on public.staff;
create policy staff_select on public.staff for select to authenticated
  using (public.is_staff() or user_id = auth.uid());
drop policy if exists staff_admin_write on public.staff;
create policy staff_admin_write on public.staff for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

-- services
drop policy if exists services_public_read on public.services;
create policy services_public_read on public.services for select to anon, authenticated
  using (active or public.is_staff());
drop policy if exists services_admin_write on public.services;
create policy services_admin_write on public.services for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

-- settings
drop policy if exists settings_public_read on public.settings;
create policy settings_public_read on public.settings for select to anon, authenticated using (true);
drop policy if exists settings_admin_write on public.settings;
create policy settings_admin_write on public.settings for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

-- clients
drop policy if exists clients_staff_read on public.clients;
create policy clients_staff_read on public.clients for select to authenticated using (public.is_staff());
drop policy if exists clients_staff_insert on public.clients;
create policy clients_staff_insert on public.clients for insert to authenticated with check (public.is_staff());
drop policy if exists clients_staff_update on public.clients;
create policy clients_staff_update on public.clients for update to authenticated
  using (public.is_staff()) with check (public.is_staff());
drop policy if exists clients_admin_delete on public.clients;
create policy clients_admin_delete on public.clients for delete to authenticated using (public.is_admin());

-- bookings
drop policy if exists bookings_public_insert on public.bookings;
create policy bookings_public_insert on public.bookings for insert to anon
  with check (
    source = 'website' and status = 'pending'
    and client_id is null and visit_id is null and handled_by is null and staff_notes is null
    and preferred_date >= (now() at time zone 'Asia/Manila')::date
    and preferred_date <= (now() at time zone 'Asia/Manila')::date + 120
  );
drop policy if exists bookings_staff_read on public.bookings;
create policy bookings_staff_read on public.bookings for select to authenticated using (public.is_staff());
drop policy if exists bookings_staff_insert on public.bookings;
create policy bookings_staff_insert on public.bookings for insert to authenticated with check (public.is_staff());
drop policy if exists bookings_staff_update on public.bookings;
create policy bookings_staff_update on public.bookings for update to authenticated
  using (public.is_staff()) with check (public.is_staff());
drop policy if exists bookings_admin_delete on public.bookings;
create policy bookings_admin_delete on public.bookings for delete to authenticated using (public.is_admin());

-- visits
drop policy if exists visits_staff_read on public.visits;
create policy visits_staff_read on public.visits for select to authenticated using (public.is_staff());
drop policy if exists visits_staff_insert on public.visits;
create policy visits_staff_insert on public.visits for insert to authenticated with check (public.is_staff());
drop policy if exists visits_staff_update on public.visits;
create policy visits_staff_update on public.visits for update to authenticated
  using (public.is_staff()) with check (public.is_staff());
-- no delete policy: visits are voided, never deleted

-- visit items
drop policy if exists items_staff_read on public.visit_items;
create policy items_staff_read on public.visit_items for select to authenticated using (public.is_staff());
drop policy if exists items_staff_insert on public.visit_items;
create policy items_staff_insert on public.visit_items for insert to authenticated with check (public.is_staff());
drop policy if exists items_staff_delete on public.visit_items;
create policy items_staff_delete on public.visit_items for delete to authenticated using (public.is_staff());

-- Explicit grants (works even if "Automatically expose new tables" is turned off).
-- RLS above still decides which rows each role can see or change.
grant usage on schema public to anon, authenticated;
grant select on public.services, public.settings to anon;
grant insert on public.bookings to anon;
grant select, insert, update, delete on
  public.staff, public.services, public.settings, public.clients,
  public.bookings, public.visits, public.visit_items
  to authenticated;
grant usage, select on all sequences in schema public to authenticated;
grant execute on function public.my_staff_id(), public.my_role(), public.is_staff(),
  public.can_manage(), public.is_admin() to anon, authenticated;
grant execute on function public.save_visit(jsonb), public.void_visit(uuid, text) to authenticated;

-- ---------------------------------------------------------------------
-- SEED: business info + 2026 pricelist
-- ---------------------------------------------------------------------
insert into public.settings (key, value) values ('business', $json${
  "name": "Movewell Wellness Center",
  "tagline": "Balance well. Live better.",
  "location": "Marikina Sports Center",
  "address": "Marikina Sports Center, Marikina City",
  "phones": ["+63 927 557 3040"],
  "instagram": "movewell.wc",
  "facebook_name": "Movewell - Wellness center",
  "facebook_url": "",
  "message_url": "https://qr.generatorqr.com/DAA5kp7Dn",
  "hours": [
    {"days": "Monday to Saturday", "time": "9:00 AM – 11:00 PM"},
    {"days": "Sunday", "time": "1:00 PM – 11:00 PM"}
  ],
  "about": "Movewell brings relaxation and self-care closer to you at Marikina Sports Center. Enjoy quality massages from our certified massage therapists and IV treatments administered by licensed doctors, all in a comfortable space designed to help you balance well and live better."
}$json$::jsonb)
on conflict (key) do nothing;

do $$ begin
if not exists (select 1 from public.services) then
  insert into public.services (category, name, duration_min, price, is_iv, coming_soon, sort_order) values
  -- Wellness massages
  ('Wellness Massage','Swedish Massage',60,799,false,false,10),
  ('Wellness Massage','Swedish Massage',90,1199,false,false,11),
  ('Wellness Massage','Deep Tissue',60,999,false,false,20),
  ('Wellness Massage','Deep Tissue',90,1299,false,false,21),
  ('Wellness Massage','Hot Stones',60,1199,false,false,30),
  ('Wellness Massage','Hot Stones',90,1399,false,false,31),
  ('Wellness Massage','Lymphatic Massage',60,999,false,false,40),
  ('Wellness Massage','Lymphatic Massage',90,1299,false,false,41),
  ('Wellness Massage','Madero Therapy Massage',90,1199,false,false,50),
  ('Wellness Massage','Pregnancy Massage',60,899,false,false,60),
  ('Wellness Massage','Postnatal Massage',60,899,false,false,70),
  ('Wellness Massage','Hilot',60,899,false,false,80),
  ('Wellness Massage','Hilot',90,1099,false,false,81),
  ('Wellness Massage','Foot Massage',30,300,false,false,90),
  ('Wellness Massage','Hydro Therapy',null,null,false,false,95),
  -- Chair massage
  ('Chair Massage','Chair Massage – Movewell',15,150,false,false,10),
  ('Chair Massage','Chair Massage – Movewell',20,200,false,false,11),
  ('Chair Massage','Chair Massage – Movewell',30,300,false,false,12),
  ('Chair Massage','Chair Massage – Move Up',15,170,false,false,20),
  ('Chair Massage','Chair Massage – Move Up',20,220,false,false,21),
  ('Chair Massage','Chair Massage – Move Up',30,320,false,false,22),
  -- Detox & IV
  ('Detox & IV Therapy','Foot Detox',null,1000,false,false,10),
  ('Detox & IV Therapy','Foot Therapy',90,1499,false,false,15),
  ('Detox & IV Therapy','Regular Vitamin C',null,5500,true,false,20),
  ('Detox & IV Therapy','High Dose Vitamin C',null,6500,true,false,21),
  ('Detox & IV Therapy','Mega Dose Vitamin C',null,7500,true,false,22),
  ('Detox & IV Therapy','Alpha Lipoic Acid',null,5000,true,false,30),
  ('Detox & IV Therapy','Gluta Push',null,2500,true,false,40),
  ('Detox & IV Therapy','Chelation',null,6000,true,false,50),
  ('Detox & IV Therapy','Plaquex',null,6000,true,false,60),
  ('Detox & IV Therapy','NAD+ Therapy',null,10000,true,false,70),
  ('Detox & IV Therapy','Meyers'' Cocktail',null,4500,true,false,80),
  ('Detox & IV Therapy','Coffee Colon Enema',null,null,false,true,90),
  -- Beauty & nails
  ('Beauty & Nails','Eyebrow Threading',null,200,false,false,10),
  ('Beauty & Nails','Manicure – Cleaning',null,120,false,false,20),
  ('Beauty & Nails','Manicure – with Basic Polish',null,150,false,false,21),
  ('Beauty & Nails','Pedicure – Cleaning',null,150,false,false,30),
  ('Beauty & Nails','Pedicure – with Basic Polish',null,180,false,false,31),
  ('Beauty & Nails','Foot Spa',null,250,false,false,40),
  ('Beauty & Nails','Hand Spa',null,200,false,false,50),
  ('Beauty & Nails','Nail Art',null,null,false,true,60),
  ('Beauty & Nails','Gel Polish',null,null,false,true,61),
  ('Beauty & Nails','Soft Gel',null,null,false,true,62),
  ('Beauty & Nails','Nail Extensions',null,null,false,true,63);
end if;
end $$;
